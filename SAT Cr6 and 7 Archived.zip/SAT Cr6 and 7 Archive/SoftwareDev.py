#imports pygame and calls it pyg
import pygame as pyg

#this initialises the pygame 
pyg.init()

#this creates the screen
main_menu = pyg.display.set_mode((1080,720))

#title and icon 
pyg.display.set_caption("Vis Novel")
game_icon = pyg.image.load("woman.png")
pyg.display.set_icon(game_icon)

#This is the background image
bcgr_img = pyg.image.load('background.jpg')
bcgrX = 0
bcgrY = 0

def bckgrnd():
    main_menu.blit(bcgr_img,(bcgrX, bcgrY))

#Game Loop 
#(This allows the user to press the quit button to stop the program and is 
#infinite)
running = True
while running: 
     #This alters the background colour of the main menu
    main_menu.fill((247, 207, 212))
    
    for event in pyg.event.get():
        if event.type == pyg.QUIT:
            running = False 

    bckgrnd()
    pyg.display.update()