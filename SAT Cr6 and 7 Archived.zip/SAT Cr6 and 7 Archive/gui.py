from tkinter import *

root = Tk()

userEntry = Entry(root, width=50, bg="white", borderwidth=2)
userEntry.pack()
userEntry.get()
userEntry.insert(0, "Enter your name")

def myClick():
    hello = "Hello" +" "+ userEntry.get()
    myLabel = Label(root, text = hello)
    myLabel.pack()

#Dont call a function with parenthesis
myButton = Button(root, text ="Enter Your Name", padx=50, command=myClick, fg="blue", bg="red")
myButton.pack()

root.mainloop()




#creating a label widget
#myLabel1 = Label(root, text="hello world!").grid(row=0, column =0)
#myLabel2 = Label(root, text="hello my name is cameron rule").grid(row=1, column =0)
#shoving it onto the screen
