# from tkinter import *
# from PIL import ImageTk, Image

# FILENAME = 'image.png'
# root = Tk.Tk()
# canvas = Tk.Canvas(root, width=250, height=250)
# canvas.pack()
# tk_img = ImageTk.PhotoImage(file = FILENAME)
# canvas.create_image(125, 125, image=tk_img)
# quit_button = Tk.Button(root, text = "Quit", command = root.quit, anchor = 'w',
#                     width = 10, activebackground = "#33B5E5")
# quit_button_window = canvas.create_window(10, 10, anchor='nw', window=quit_button)    
# root.mainloop()

# root.mainloop()